%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                      %
%                      Runge Kutta 1st Order                           %
%                                                                      %
%                     By :- Er. Pankaj Bagga                           %
%                          email : pnkjbagga@live.in                   %
%                          www.pankajbagga.com                         %
%                          +33 752122021                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                      %
%                     E2MATRIX Research LAB                            %
%                                                                      %
%                    Email   : support@e2matrix.com                    %
%                    Website : www.e2matrix.com                        %
%                    Blog    : www.e2matrix.com/blog                   %
%                    Tel     : +91 9041262727                          %
%                              +91 9779363902                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%

clc;
clear all;
%Script that demonstrates the Runge-Kutta integration for a first order problem using Matlab.

% The problem to be solved is:

%y'(t) = 3*exp(-4*t) - 2*y(t) ;

h=0.1;		%h is the time step.
t=1:h:4;	%initialize time variable.
yPrimeStar(1)=1.0;	%initial condition (same for approximation).

for i=1:length(t) - 1,	%Set up "for" loop.
   k1=3*exp(-4*t(i))-2*yPrimeStar(i);	%Calculate derivative;
   ystar=yPrimeStar(i)+h*k1;				%Estimate new value of y*(to+h).
   k2=3*exp(-4*(t(i)+h))-2*ystar;		%Calculate derivative at end of step.
   yPrimeStar(i+1)=yPrimeStar(i)+h*(k1+k2)/2;		%Estimate new value of y'*(to+h).
end

%Plot approximate and exact solution.
figure,plot(t,yPrimeStar);
legend('Approximate','Exact');
title('Euler Approximation, h=0.1');
xlabel('Time');
ylabel('y*(t), y(t)');

%===================================================================
%yf'(z) = -4.2224*9.6 * 6.97 * 0.636 * yf(z) * yf(z) * exp( - 101.5 / (8.314 *525 * (1+Q))) * exp ( - 9.6 *z ) ;

h=0.1;		%h is the time step.
z = 0:h:4;	%initialize time variable.
yPrimeStar1(1)=1.0;	%initial condition (same for approximation).
Q=0 ;
yPrimeStar2(1) = 1.0 ;
yPrimeStar3(1) = 1.0 ;
for i=1:length(z)-1      	%Set up "for" loop.
   k1=-4.2224*9.6 * 6.97 * 0.636 * yPrimeStar1(i) * yPrimeStar1(i) * exp( - 101.5 / (8.314 *525 * (1+Q))) * exp ( - 9.6 *z(i) ) ;	%Calculate derivative;
   ystar1(i)=yPrimeStar1(i)+h*k1;				%Estimate new value of y*(to+h).
   k2=-4.2224*9.6 * 6.97 * 0.636 * ystar1(i) * ystar1(i) * exp( - 101.5 / (8.314 *525 * (1+Q))) * exp ( - 9.6 *(z(i) +h) ) ;		%Calculate derivative at end of step.
   yPrimeStar1(i+1)=yPrimeStar1(i)+h*(k1+k2)/2;		%Estimate new value of y'*(to+h).
% end
% 
%Plot approximate and exact solution.
% figure,plot(z,yPrimeStar1) ;
% legend('Approximate','Exact') ;
% title('Euler Approximation, h=0.1') ;
% xlabel('Time');
% ylabel('y*(t), y(t)');

% =========================================================================
% yg'(z) =  -4.2224*9.6 * 6.97 * 0.636 * yf(z) * yf(z) * exp( - 101.5 / (8.314 * 525 * (1+Q) )) * exp ( - 9.6 * z)  ...
%- 4.224 *10^5 * 9.6 * 6.97 * 0.636 * yg(z) * exp( - 101.5 / (8.314 * 525 *(1+Q) )) * exp ( - 9.6 * z ) ;

%  for i=1:length(z)-1 
% k3=-4.2224*9.6 * 6.97 * 0.636 * yPrimeStar1 * yPrimeStar1 * exp( - 101.5 / (8.314 * 525 * (1+Q) )) * exp ( - 9.6 *z )  ...
%   - 4.224 *10^5 * 9.6 * 6.97 * 0.636 * yPrimeStar2(i) * exp( - 101.5 / (8.314 * 525 * (1+Q) )) * exp ( - 9.6 *z) ;	%Calculate derivative;
%  ystar2(i) = yPrimeStar2(i)+(h*k3);				%Estimate new value of y*(fo+h).
%  k4= -4.2224*9.6 * 6.97 * 0.636 * yPrimeStar1 * yPrimeStar1 * exp( - 101.5 / (8.314 * 525 * (1+Q) )) * exp ( - 9.6 *z(i) +h )  ...
%  - 4.224 *10^5 * 9.6 * 6.97 * 0.636 * ystar2(i) * exp( - 101.5 / (8.314 * 525 * (1+Q) )) * exp ( - 9.6 *z(i) +h) ;	%Calculate derivative at end of step.
%  yPrimeStar2(i+1)=yPrimeStar2(i)+h*(k3+k4)/2 ;	
% 
%  end
% figure,plot( z, yPrimeStar2) ;

%==========================================================================
%Q'(z) = (0.965 * 506.2 * 40.63) / ( 525 *(283.3  * 1.005  + 0.965 *3.1335...
%+(1-0.965) 3.36 * 1.9 ))  * yf'(z) ;
 
% for i=1:length(z)-1 
yPrimeStar3 = (0.965 * 506.2 * 40.63) / ( 525 *(283.3  * 1.005  + 0.965 *3.1335+ (1-0.965)* 3.36 * 1.9 ))  * yPrimeStar1 ;

% end
% plot( z, yPrimeStar3) ;

end
figure,
subplot(1,2,1);
%Plot approximate and exact solution.
plot(z,yPrimeStar1) ;
legend('Approximate','Exact') ;
title('Euler Approximation, h=0.1') ;
xlabel('Time');
ylabel('y*(t), y(t)');

% subplot(1,3,2) ;
% plot( z, yPrimeStar2) ;

subplot(1,2,2) ;
plot( z, yPrimeStar3) ;
